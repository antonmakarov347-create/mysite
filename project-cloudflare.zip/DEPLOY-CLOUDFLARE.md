# Деплой на Cloudflare Workers

Имя воркера: **muddy-morning-cac9**  
URL после деплоя: `https://muddy-morning-cac9.<ваш-сабакаунт>.workers.dev`

## Вариант 1 — быстрый (статические файлы, как предложил Cloudflare)

Уже подготовлена папка `dist/` и конфиг `wrangler.static.jsonc`.

```bash
# войти в Cloudflare (один раз)
npx wrangler login

# задеплоить статику
npx wrangler deploy -c wrangler.static.jsonc
```

Сайт будет на `muddy-morning-cac9.*.workers.dev`.  
Формы лидов идут на внешний DrCash — они продолжат работать.

---

## Вариант 2 — полный SSR (рекомендуется для TanStack Start)

```bash
npm install
npm install -D wrangler @cloudflare/vite-plugin

# сборка под Cloudflare
CF=1 npm run build:cf

# деплой
npx wrangler deploy
```

Или одной командой (после установки зависимостей):

```bash
npm run deploy
```

---

## Если деплой падает

1. Убедитесь, что вы залогинены: `npx wrangler whoami`
2. Имя в `wrangler.jsonc` / `wrangler.static.jsonc` можно поменять
3. Для статики путь к файлам: `"directory": "./dist"`
4. После изменений в коде снова: `CF=1 npm run build:cf && npx wrangler deploy`
