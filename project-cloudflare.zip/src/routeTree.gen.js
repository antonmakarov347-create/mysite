import { Route as rootRouteImport } from "./routes/__root";
import { Route as IndexRouteImport } from "./routes/index";
import { Route as ThanksRouteImport } from "./routes/thanks";
const IndexRoute = IndexRouteImport.update({
  id: "/",
  path: "/",
  getParentRoute: () => rootRouteImport
});
const ThanksRoute = ThanksRouteImport.update({
  id: "/thanks",
  path: "/thanks",
  getParentRoute: () => rootRouteImport
});
const rootRouteChildren = {
  IndexRoute,
  ThanksRoute
};
const routeTree = rootRouteImport._addFileChildren(rootRouteChildren)._addFileTypes();
export {
  routeTree
};
