import { jsx, jsxs } from "react/jsx-runtime";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, PhoneCall, Volume2 } from "lucide-react";
import { BrandMark } from "@/components/landing/brand-mark";
const Route = createFileRoute("/thanks")({ component: ThanksPage });
function ThanksPage() {
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-navy-deep", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex min-h-screen w-full max-w-md flex-col bg-cream px-5 pb-10 pt-8", children: [
    /* @__PURE__ */ jsx(BrandMark, { tone: "light" }),
    /* @__PURE__ */ jsxs("div", { className: "mt-10 flex flex-1 flex-col items-center text-center", children: [
      /* @__PURE__ */ jsx("span", { className: "flex size-20 items-center justify-center rounded-full bg-green text-paper shadow-lg", children: /* @__PURE__ */ jsx(CheckCircle2, { className: "size-12", strokeWidth: 2.2 }) }),
      /* @__PURE__ */ jsx("h1", { className: "mt-6 font-display text-3xl font-extrabold leading-tight text-ink", children: "Asante kwa ununuzi wako!" }),
      /* @__PURE__ */ jsx("p", { className: "mt-4 max-w-sm text-base leading-relaxed text-ink", children: "Hakikisha simu yako imewashwa \u2014 opereta wetu atakupigia hivi karibuni." }),
      /* @__PURE__ */ jsxs("ul", { className: "mt-8 w-full space-y-3 text-left", children: [
        /* @__PURE__ */ jsxs("li", { className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm", children: [
          /* @__PURE__ */ jsx(PhoneCall, { className: "mt-0.5 size-5 shrink-0 text-navy" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted", children: "Tafadhali usikatae simu isiyojulikana. Inaweza kuwa opereta anayethibitisha oda yako." })
        ] }),
        /* @__PURE__ */ jsxs("li", { className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm", children: [
          /* @__PURE__ */ jsx(Volume2, { className: "mt-0.5 size-5 shrink-0 text-navy" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted", children: "Weka sauti wazi na uhakikishe simu haiko kwenye mode ya kimya." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 w-full overflow-hidden rounded-xl bg-navy p-4 text-left text-paper", children: [
        /* @__PURE__ */ jsx("p", { className: "text-xs font-bold uppercase tracking-widest text-gold", children: "Oda yako" }),
        /* @__PURE__ */ jsx("p", { className: "mt-1 font-display text-lg font-bold", children: "Bioforce Europa \xB7 30 kapsuli" }),
        /* @__PURE__ */ jsx("p", { className: "mt-1 text-gold-bright", children: "6,750 KES \xB7 Lipa unapopokea" })
      ] }),
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/product.jpg",
          alt: "Chupa ya Bioforce Europa",
          className: "mt-6 h-48 w-full object-contain"
        }
      )
    ] })
  ] }) });
}
export {
  Route
};
