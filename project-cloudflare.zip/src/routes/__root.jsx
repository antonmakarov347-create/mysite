import { jsx, jsxs } from "react/jsx-runtime";
import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { TikTokPixel } from "@/components/tiktok-pixel";
import appCss from "../styles.css?url";
const APP_NAME = "Bioforce Europa \u2014 Kapsuli za Viungo";
const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      {
        name: "description",
        content: "Bioforce Europa \u2014 kapsuli za viungo nchini Kenya. Punguzo 50%, bei 6,750 KES. Lipa unapopokea."
      },
      { name: "theme-color", content: "#163A72" }
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=Sora:wght@600;700;800&display=swap"
      }
    ]
  }),
  component: () => /* @__PURE__ */ jsxs("html", { lang: "sw", suppressHydrationWarning: true, children: [
    /* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxs("body", { className: "font-sans antialiased", children: [
      /* @__PURE__ */ jsx(PreviewHostBridge, {}),
      /* @__PURE__ */ jsx(TikTokPixel, {}),
      /* @__PURE__ */ jsx(AuthProvider, { children: /* @__PURE__ */ jsx(Outlet, {}) }),
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] })
});
export {
  Route
};
