import { jsx } from "react/jsx-runtime";
import { createFileRoute } from "@tanstack/react-router";
import { LandingPage } from "@/components/landing/landing-page";
const Route = createFileRoute("/")({ component: Home });
function Home() {
  return /* @__PURE__ */ jsx(LandingPage, {});
}
export {
  Route
};
