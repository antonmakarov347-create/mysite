import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { ChevronRight } from "lucide-react";
const QUESTIONS = [
  {
    title: "1. Baada ya siku ndefu ya kazi, viungo vyako huhisi vizito na ngumu:",
    options: ["Mara chache", "Mara nyingi sana", "Kila wakati"]
  },
  {
    title: "2. Umewahi kupata majeraha, kuteguka, michubuko au kuvunjika?",
    options: [
      "Ndiyo, kila baada ya miaka michache",
      "Hakuna kilichohitaji hospitali",
      "Majeraha madogo tu"
    ]
  },
  {
    title: "3. Una miaka mingapi?",
    options: ["Chini ya 30", "30 \u2013 45", "Zaidi ya 45"]
  }
];
function Quiz() {
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState(null);
  const done = step >= QUESTIONS.length;
  const question = QUESTIONS[step];
  function goNext() {
    if (picked === null) return;
    setPicked(null);
    setStep((value) => value + 1);
  }
  return /* @__PURE__ */ jsx("section", { className: "px-4 py-8", children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl bg-navy p-5 text-paper shadow-lg", children: [
    /* @__PURE__ */ jsx("p", { className: "mb-1 text-xs font-bold uppercase tracking-widest text-gold", children: "Uchunguzi wa haraka" }),
    /* @__PURE__ */ jsx("h2", { className: "font-display text-xl font-bold", children: "Je, unahitaji Bioforce? Jibu maswali 3" }),
    done ? /* @__PURE__ */ jsxs("div", { className: "mt-5 rounded-lg bg-navy-deep p-4", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-sm leading-relaxed text-cream", children: [
        "Jeraha au mchubuko linaweza kutokea wakati wowote.",
        " ",
        /* @__PURE__ */ jsx("span", { className: "font-bold text-gold-bright", children: "Bioforce" }),
        " husaidia kupunguza maumivu, kuvimba na ugumu \u2014 na kuchochea cartilage yenye afya. Kozi ya kapsuli 30 inakupa faraja ya kila siku."
      ] }),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "#oda",
          className: "mt-4 flex h-12 items-center justify-center rounded-md bg-cta text-sm font-extrabold uppercase tracking-wide text-paper",
          children: "Pata ofa ya 50%"
        }
      )
    ] }) : /* @__PURE__ */ jsxs("div", { className: "mt-5", children: [
      /* @__PURE__ */ jsx("p", { className: "mb-3 text-sm font-semibold leading-snug", children: question.title }),
      /* @__PURE__ */ jsx("ul", { className: "space-y-2", children: question.options.map((option, index) => {
        const active = picked === index;
        return /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: () => setPicked(index),
            className: `flex min-h-11 w-full items-center rounded-md border px-3 py-2 text-left text-sm font-medium ${active ? "border-gold bg-gold/15 text-gold-bright" : "border-paper/15 bg-navy-deep text-cream"}`,
            children: option
          }
        ) }, option);
      }) }),
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          disabled: picked === null,
          onClick: goNext,
          className: "mt-4 flex h-12 w-full items-center justify-center gap-1 rounded-md bg-gold text-sm font-extrabold uppercase tracking-wide text-navy-deep disabled:opacity-40",
          children: [
            "Endelea",
            /* @__PURE__ */ jsx(ChevronRight, { className: "size-4" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("p", { className: "mt-3 text-center text-xs text-cream/50", children: [
        "Swali ",
        step + 1,
        " kati ya ",
        QUESTIONS.length
      ] })
    ] })
  ] }) });
}
export {
  Quiz
};
