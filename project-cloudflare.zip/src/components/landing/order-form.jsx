import { jsx, jsxs } from "react/jsx-runtime";
import { cn } from "@/lib/utils";
function sanitizePhone(value) {
  return value.replace(/\s/g, "");
}
function OrderForm({ idPrefix, compact = false }) {
  return /* @__PURE__ */ jsxs("form", { className: "orderForm flex flex-col gap-2", method: "post", children: [
    /* @__PURE__ */ jsxs("div", { className: cn("grid gap-2", compact ? "grid-cols-2" : "grid-cols-1"), children: [
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        compact ? /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Jina" }) : /* @__PURE__ */ jsx("span", { className: "mb-1 block text-xs font-bold uppercase tracking-wide text-cream/80", children: "Jina" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            id: `${idPrefix}-name`,
            name: "name",
            type: "text",
            required: true,
            autoComplete: "name",
            placeholder: "Jina lako",
            suppressHydrationWarning: true,
            className: "h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted focus:border-gold"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        compact ? /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Nambari ya simu" }) : /* @__PURE__ */ jsx("span", { className: "mb-1 block text-xs font-bold uppercase tracking-wide text-cream/80", children: "Nambari ya simu" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            id: `${idPrefix}-phone`,
            name: "phone",
            type: "tel",
            inputMode: "tel",
            required: true,
            minLength: 5,
            autoComplete: "tel",
            placeholder: "07XXXXXXXX",
            suppressHydrationWarning: true,
            className: "only_number h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted focus:border-gold",
            onInput: (event) => {
              const target = event.currentTarget;
              target.value = sanitizePhone(target.value);
            }
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "submit",
        className: "cta-pulse button__text h-12 w-full rounded-md bg-cta text-base font-extrabold uppercase tracking-wide text-paper shadow-lg hover:bg-cta-dark",
        children: "Agiza sasa \u2014 6,750 KES"
      }
    )
  ] });
}
export {
  OrderForm
};
