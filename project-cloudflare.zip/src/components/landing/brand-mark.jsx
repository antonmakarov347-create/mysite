import { jsx, jsxs } from "react/jsx-runtime";
function BrandMark({
  compact = false,
  tone = "dark"
}) {
  const word = tone === "dark" ? "text-gold-bright" : "text-navy";
  const sub = tone === "dark" ? "text-gold/80" : "text-muted";
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5", children: [
    /* @__PURE__ */ jsxs(
      "svg",
      {
        viewBox: "0 0 64 64",
        className: compact ? "size-8" : "size-11",
        "aria-hidden": "true",
        children: [
          /* @__PURE__ */ jsx(
            "path",
            {
              d: "M32 4.5 54 15.2v18.6c0 14.6-9.3 25.8-22 29.7C19.3 59.6 10 48.4 10 33.8V15.2Z",
              className: "fill-navy-deep stroke-gold",
              strokeWidth: "3"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              d: "M36.2 14 22 34.4h11.2L24.8 50.5 43.6 31H32.2L36.2 14Z",
              className: "fill-gold-bright"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "leading-tight", children: [
      /* @__PURE__ */ jsx("div", { className: `font-display font-extrabold tracking-wide ${word} ${compact ? "text-sm" : "text-lg"}`, children: "BIOFORCE" }),
      !compact ? /* @__PURE__ */ jsx("div", { className: `text-xs font-semibold uppercase tracking-widest ${sub}`, children: "Europa \xB7 Kenya" }) : null
    ] })
  ] });
}
export {
  BrandMark
};
