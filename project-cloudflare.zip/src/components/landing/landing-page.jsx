import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import {
  AlertTriangle,
  BadgeCheck,
  Check,
  ChevronDown,
  Clock,
  Leaf,
  Package,
  PhoneCall,
  Shield,
  Sparkles,
  Star,
  Truck,
  Zap
} from "lucide-react";
import { initDrCash } from "@/lib/drcash";
import { BrandMark } from "./brand-mark";
import { Countdown } from "./countdown";
import { OrderForm } from "./order-form";
import { Quiz } from "./quiz";
import { StickyForm } from "./sticky-form";
const BENEFITS = [
  "Inapunguza maumivu ya viungo na mgongo",
  "Inachochea kuzaliwa upya kwa cartilage",
  "Inapunguza ugumu, mvutano wa misuli na uvimbe",
  "Inasaidia unyumbufu, mwendo na faraja",
  "Inazuia kuvimba na kulinda kiungo"
];
const ADVANTAGES = [
  {
    icon: Sparkles,
    title: "Madhara mengi kwa pamoja",
    text: "Husaidia viungo, mgongo, ugumu wa asubuhi na majeraha ya zamani."
  },
  {
    icon: Shield,
    title: "Salama \u2014 bila madhara makali",
    text: "Muundo wa asili, unaofaa kwa matumizi ya kila siku au kozi kamili."
  },
  {
    icon: Leaf,
    title: "Vipengele vya mimea 100%",
    text: "Mimea hai pekee \u2014 hakuna steroidi wala dawa za kulevya."
  },
  {
    icon: Zap,
    title: "Ufanisi unaoonekana",
    text: "Wengi huripoti faraja baada ya siku chache za matumizi ya kawaida."
  },
  {
    icon: BadgeCheck,
    title: "Imepimwa na wataalamu",
    text: "Imetajwa Poland. Inakidhi viwango vya ubora vya Europa."
  }
];
const STEPS_USE = [
  "Kumeza kapsuli 1 na glasi ya maji, baada ya chakula.",
  "Tumia mara 1\u20132 kwa siku \u2014 asubuhi na jioni.",
  "Endelea kwa siku 30 (chupa 1) kwa matokeo thabiti."
];
const STEPS_ORDER = [
  { icon: Package, text: "Jaza jina na nambari ya simu kwenye fomu" },
  { icon: PhoneCall, text: "Opereta atakupigia kuthibitisha oda" },
  { icon: Truck, text: "Lipa bidhaa unapoipokea \u2014 Kenya nzima" }
];
const REVIEWS = [
  {
    name: "Amina W.",
    place: "Nairobi, miaka 52",
    text: "Goti langu lilikuwa linaniuma kila nitembee soko. Baada ya wiki mbili za Bioforce, ninatembea bila kuogopa ngazi."
  },
  {
    name: "John K.",
    place: "Kisumu, miaka 61",
    text: "Mgongo ulikuwa unanishika kila asubuhi. Sasa naamka, naweza kufanya kazi shambani bila kulazimisha."
  },
  {
    name: "Grace M.",
    place: "Mombasa, miaka 47",
    text: "Vidole vilikuwa vimekaza, sikuweza kushona. Faraja imerudi \u2014 nimeagiza chupa ya pili."
  },
  {
    name: "Peter O.",
    place: "Nakuru, miaka 58",
    text: "Nilikuwa na wasiwasi ni bandia. Opereta alieleza vizuri, chupa ilifika kwa siku 2. Ninaendelea na kozi."
  }
];
const FAQ = [
  {
    q: "Bioforce ni nini?",
    a: "Ni kapsuli 30 za lishe ya viungo \u2014 Bioforce Europa. Inasaidia unyumbufu, faraja, cartilage yenye afya na kupunguza ugumu na kuvimba."
  },
  {
    q: "Inachukua muda gani kuona tofauti?",
    a: "Wengi huhisi faraja ndani ya siku 5\u201310. Kozi kamili ya siku 30 inapendekezwa ili cartilage na viungo vipate msaada thabiti."
  },
  {
    q: "Kuna madhara?",
    a: "Muundo ni wa mimea. Ikiwa una mzio, una mimba, au unatumia dawa nyingine, shauri na daktari kabla ya kuanza."
  },
  {
    q: "Nitalipaje?",
    a: "Unalipa unapopokea bidhaa (cash on delivery). Hakuna malipo ya awali kwenye simu."
  },
  {
    q: "Inafika wapi Kenya?",
    a: "Tunatuma Nairobi, Mombasa, Kisumu, Nakuru, Eldoret na kaunti nyingine. Opereta atakwambia gharama ya usafirishaji kabla hujaidhinisha."
  },
  {
    q: "Ni kapsuli ngapi kwenye chupa?",
    a: "Kapsuli 30 \u2014 kozi ya takriban mwezi mmoja ikiwa unatumia moja kwa siku."
  },
  {
    q: "Watoto wanaweza kutumia?",
    a: "Bidhaa hii ni kwa watu wazima. Usitoe kwa watoto bila ushauri wa daktari."
  }
];
function SectionTitle({
  kicker,
  children
}) {
  return /* @__PURE__ */ jsxs("header", { className: "mb-4", children: [
    kicker ? /* @__PURE__ */ jsx("p", { className: "mb-1 text-xs font-bold uppercase tracking-widest text-gold", children: kicker }) : null,
    /* @__PURE__ */ jsx("h2", { className: "font-display text-2xl font-bold leading-snug text-ink", children })
  ] });
}
function FaqList() {
  const [open, setOpen] = useState(0);
  return /* @__PURE__ */ jsx("ul", { className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-paper", children: FAQ.map((item, index) => {
    const isOpen = open === index;
    return /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          className: "flex min-h-12 w-full items-center justify-between gap-3 px-4 py-3 text-left",
          onClick: () => setOpen(isOpen ? -1 : index),
          "aria-expanded": isOpen,
          children: [
            /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-ink", children: item.q }),
            /* @__PURE__ */ jsx(
              ChevronDown,
              {
                className: `size-4 shrink-0 text-navy transition-transform ${isOpen ? "rotate-180" : ""}`
              }
            )
          ]
        }
      ),
      isOpen ? /* @__PURE__ */ jsx("p", { className: "px-4 pb-4 text-sm leading-relaxed text-muted", children: item.a }) : null
    ] }, item.q);
  }) });
}
function LandingPage() {
  useEffect(() => initDrCash(), []);
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-navy-deep", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative mx-auto min-h-screen w-full max-w-md bg-cream pb-52 shadow-2xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex h-1.5", children: [
        /* @__PURE__ */ jsx("span", { className: "flex-1 bg-navy-deep" }),
        /* @__PURE__ */ jsx("span", { className: "flex-1 bg-gold" }),
        /* @__PURE__ */ jsx("span", { className: "flex-1 bg-green" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between bg-navy px-4 py-2 text-xs font-semibold text-cream", children: [
        /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsx(Truck, { className: "size-3.5 text-gold" }),
          "Kenya nzima"
        ] }),
        /* @__PURE__ */ jsx("span", { children: "Lipa unapopokea" }),
        /* @__PURE__ */ jsx("span", { className: "text-gold-bright", children: "Ofa 50%" })
      ] }),
      /* @__PURE__ */ jsxs("header", { className: "relative overflow-hidden bg-navy px-4 pb-28 pt-6 text-paper", children: [
        /* @__PURE__ */ jsx(BrandMark, {}),
        /* @__PURE__ */ jsx("p", { className: "mt-4 text-xs font-bold uppercase tracking-widest text-gold", children: "Kapsuli za viungo \xB7 30 kapsuli" }),
        /* @__PURE__ */ jsx("h1", { className: "mt-2 font-display text-3xl font-extrabold leading-tight", children: "Viungo vinauma au mgongo unashindwa?" }),
        /* @__PURE__ */ jsxs("p", { className: "mt-3 text-sm leading-relaxed text-cream/90", children: [
          /* @__PURE__ */ jsx("span", { className: "font-bold text-gold-bright", children: "Bioforce Europa" }),
          " ni kapsuli za asili zinazosaidia unyumbufu, faraja, cartilage yenye afya \u2014 na kupunguza ugumu na kuvimba."
        ] }),
        /* @__PURE__ */ jsx(
          "svg",
          {
            className: "absolute inset-x-0 bottom-0 h-12 w-full text-cream",
            viewBox: "0 0 400 48",
            preserveAspectRatio: "none",
            "aria-hidden": "true",
            children: /* @__PURE__ */ jsx("path", { d: "M0 48 C80 8 140 8 200 24 C280 44 320 0 400 24 L400 48 Z", fill: "currentColor" })
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "relative z-10 -mt-24 px-4", children: /* @__PURE__ */ jsxs("div", { className: "overflow-hidden rounded-xl bg-paper shadow-xl", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative bg-paper", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              src: "/product.jpg",
              alt: "Chupa ya kapsuli za Bioforce Europa, kapsuli 30",
              className: "mx-auto h-72 w-full object-contain"
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "absolute left-3 top-3 rounded-full bg-cta px-3 py-2 text-center shadow-md", children: [
            /* @__PURE__ */ jsx("div", { className: "text-xs font-bold uppercase text-paper", children: "Punguzo" }),
            /* @__PURE__ */ jsx("div", { className: "font-display text-2xl font-extrabold leading-none text-paper", children: "50%" })
          ] })
        ] }),
        /* @__PURE__ */ jsx("ul", { className: "space-y-2 px-4 py-4", children: BENEFITS.map((item) => /* @__PURE__ */ jsxs("li", { className: "flex gap-2 text-sm font-medium text-ink", children: [
          /* @__PURE__ */ jsx(Check, { className: "mt-0.5 size-4 shrink-0 text-green", strokeWidth: 3 }),
          item
        ] }, item)) })
      ] }) }),
      /* @__PURE__ */ jsx("section", { className: "px-4 pt-6", children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl bg-green px-4 py-5 text-center text-paper shadow-lg", children: [
        /* @__PURE__ */ jsx("p", { className: "text-xs font-bold uppercase tracking-widest text-gold-bright", children: "Bei ya ofa leo" }),
        /* @__PURE__ */ jsxs("div", { className: "mt-1 flex items-end justify-center gap-3", children: [
          /* @__PURE__ */ jsx("span", { className: "font-display text-4xl font-extrabold tabular-nums", children: "6,750" }),
          /* @__PURE__ */ jsx("span", { className: "pb-1 text-lg font-bold", children: "KES" })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "mt-1 text-sm", children: [
          "Bei ya kawaida",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold line-through opacity-80", children: "13,500 KES" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(Countdown, {}) }),
        /* @__PURE__ */ jsx("p", { className: "stock-blink mt-3 text-xs font-bold uppercase tracking-wide text-gold-bright", children: "Chupa 19 zimesalia kwa bei hii" }),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "#oda",
            className: "cta-pulse mt-4 flex h-12 items-center justify-center rounded-md bg-cta text-sm font-extrabold uppercase tracking-wide text-paper",
            children: "Agiza sasa"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Tatizo", children: "Maumivu ya viungo yanaiba siku zako" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted", children: "Kazi ya shamba, kusimama sokoni, kukaa ofisini, au umri \u2014 viungo huchakaa. Ugumu wa asubuhi, goti linalolia ngazi, mgongo unaoshindwa kuinama. Wakenya wengi huvumilia hadi faraja ya kawaida inapotea." }),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/kenya.jpg",
            alt: "Milima ya Kenya yenye kijani \u2014 tunatuma nchi nzima",
            className: "mt-4 h-40 w-full rounded-xl object-cover"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-sm leading-relaxed text-muted", children: "Bioforce imeundwa kusaidia cartilage, kupunguza kuvimba na kurudisha mwendo. Si dawa ya muujiza wa usiku mmoja \u2014 ni msaada wa kila siku, chupa moja ya kapsuli 30." })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Jinsi inavyofanya kazi", children: "Cartilage yenye afya, viungo vyenye faraja" }),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/joint.jpg",
            alt: "Mchoro wa kiungo na cartilage",
            className: "mb-4 h-56 w-full rounded-xl object-cover"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-sm leading-relaxed text-muted", children: [
          /* @__PURE__ */ jsxs("p", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-ink", children: "Bioforce" }),
            " inalenga osteochondrosis, osteoarthritis na majeraha ya zamani. Inapunguza mshtuko wa misuli na kuvimba, inapunguza kasi ya uharibifu wa cartilage, na inaboresha mzunguko ili kiungo kipate lishe."
          ] }),
          /* @__PURE__ */ jsx("p", { children: "Matumizi ya kawaida husaidia kusimamisha maumivu ya viungo na mgongo. Wengi huhisi tofauti baada ya siku chache \u2014 kozi kamili inalinda matokeo." })
        ] }),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "#oda",
            className: "mt-4 flex h-12 items-center justify-center rounded-md bg-navy text-sm font-extrabold uppercase tracking-wide text-gold-bright",
            children: "Bioforce hutumia vipengele hai"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Muundo", children: "Mimea hai, si kemikali kali" }),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/herbs.jpg",
            alt: "Mimea ya asili inayotumika katika nyongeza ya viungo",
            className: "mb-4 h-44 w-full rounded-xl object-cover"
          }
        ),
        /* @__PURE__ */ jsx("ul", { className: "grid grid-cols-2 gap-2", children: [
          "Msaada wa cartilage",
          "Kupunguza kuvimba",
          "Unyumbufu wa kiungo",
          "Faraja ya kila siku"
        ].map((item) => /* @__PURE__ */ jsx(
          "li",
          {
            className: "rounded-lg bg-paper px-3 py-3 text-center text-xs font-bold text-navy shadow-sm",
            children: item
          },
          item
        )) })
      ] }),
      /* @__PURE__ */ jsx(Quiz, {}),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pb-2", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Kwa nini Bioforce", children: "Faida za kapsuli kwa mgongo na viungo" }),
        /* @__PURE__ */ jsx("ul", { className: "space-y-3", children: ADVANTAGES.map((item) => /* @__PURE__ */ jsxs(
          "li",
          {
            className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm",
            children: [
              /* @__PURE__ */ jsx("span", { className: "flex size-11 shrink-0 items-center justify-center rounded-lg bg-navy text-gold", children: /* @__PURE__ */ jsx(item.icon, { className: "size-5" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("h3", { className: "font-display text-sm font-bold uppercase tracking-wide text-navy", children: item.title }),
                /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm leading-relaxed text-muted", children: item.text })
              ] })
            ]
          },
          item.title
        )) })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-6", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Matumizi", children: "Jinsi ya kutumia Bioforce" }),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/capsules.jpg",
            alt: "Kapsuli nyeupe za Bioforce",
            className: "mb-4 h-40 w-full rounded-xl object-cover"
          }
        ),
        /* @__PURE__ */ jsx("ol", { className: "space-y-3", children: STEPS_USE.map((text, index) => /* @__PURE__ */ jsxs("li", { className: "flex gap-3 rounded-xl bg-paper p-4", children: [
          /* @__PURE__ */ jsx("span", { className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-green font-display text-sm font-extrabold text-paper", children: index + 1 }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium leading-relaxed text-ink", children: text })
        ] }, text)) })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Ushuhuda", children: "Wakenya wanaosema wamerudi kutembea" }),
        /* @__PURE__ */ jsx("ul", { className: "space-y-3", children: REVIEWS.map((review) => /* @__PURE__ */ jsxs("li", { className: "rounded-xl bg-paper p-4 shadow-sm", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("span", { className: "flex size-10 items-center justify-center rounded-full bg-navy font-display text-sm font-bold text-gold", children: review.name.slice(0, 1) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-ink", children: review.name }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-muted", children: review.place })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "ml-auto flex gap-0.5 text-gold", children: Array.from({ length: 5 }).map((_, star) => /* @__PURE__ */ jsx(Star, { className: "size-3.5 fill-gold text-gold" }, star)) })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-sm leading-relaxed text-muted", children: [
            "\u201C",
            review.text,
            "\u201D"
          ] })
        ] }, review.name)) })
      ] }),
      /* @__PURE__ */ jsx("section", { className: "px-4 pt-8", children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl border-2 border-cta bg-paper p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center gap-2 text-cta-dark", children: [
          /* @__PURE__ */ jsx(AlertTriangle, { className: "size-5" }),
          /* @__PURE__ */ jsx("h2", { className: "font-display text-base font-extrabold uppercase", children: "Jihadhari na bandia" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted", children: "Agiza tu kupitia fomu hii rasmi. Opereta atathibitisha oda na anwani. Usilipie kwa M-Pesa kabla ya kupokea bidhaa \u2014 Bioforce hulipwa unapopokea." })
      ] }) }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Oda", children: "Jinsi ya kuagiza Bioforce Kenya" }),
        /* @__PURE__ */ jsx("ul", { className: "space-y-3", children: STEPS_ORDER.map((item, index) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx("span", { className: "flex size-12 shrink-0 items-center justify-center rounded-full bg-navy text-gold", children: /* @__PURE__ */ jsx(item.icon, { className: "size-5" }) }),
          /* @__PURE__ */ jsxs("p", { className: "text-sm font-semibold text-ink", children: [
            /* @__PURE__ */ jsxs("span", { className: "mr-2 font-display text-gold", children: [
              index + 1,
              "."
            ] }),
            item.text
          ] })
        ] }, item.text)) })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "px-4 pt-8", children: [
        /* @__PURE__ */ jsx(SectionTitle, { kicker: "Maswali", children: "Maswali yanayoulizwa sana" }),
        /* @__PURE__ */ jsx(FaqList, {})
      ] }),
      /* @__PURE__ */ jsx("section", { id: "oda", className: "scroll-mt-4 px-4 py-8", children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl bg-navy p-5 text-paper shadow-xl", children: [
        /* @__PURE__ */ jsx("p", { className: "text-center text-xs font-bold uppercase tracking-widest text-gold", children: "Ofa ndogo yenye punguzo" }),
        /* @__PURE__ */ jsx("h2", { className: "mt-1 text-center font-display text-2xl font-bold", children: "Bioforce Europa \u2014 30 kapsuli" }),
        /* @__PURE__ */ jsx("div", { className: "mt-3 flex items-end justify-center gap-3", children: /* @__PURE__ */ jsx("span", { className: "font-display text-4xl font-extrabold tabular-nums text-gold-bright", children: "6,750 KES" }) }),
        /* @__PURE__ */ jsx("p", { className: "mt-1 text-center text-sm text-cream/70 line-through", children: "13,500 KES" }),
        /* @__PURE__ */ jsx("div", { className: "mx-auto mt-3 w-fit rounded-full bg-green px-3 py-1 text-xs font-bold uppercase tracking-wide", children: "Lipa unapopokea \xB7 Kenya nzima" }),
        /* @__PURE__ */ jsx("div", { className: "mt-5", children: /* @__PURE__ */ jsx(OrderForm, { idPrefix: "main" }) }),
        /* @__PURE__ */ jsxs("p", { className: "mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-cream/70", children: [
          /* @__PURE__ */ jsx(Clock, { className: "size-3.5" }),
          "Opereta atakupigia leo, simu iwe wazi"
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("footer", { className: "px-4 pb-8 text-center", children: /* @__PURE__ */ jsx("p", { className: "text-xs leading-relaxed text-muted", children: "Bioforce ni nyongeza ya lishe, si dawa, na haichukui nafasi ya ushauri wa daktari. Shauri na mtaalamu kabla ya matumizi, hasa ukiwa na magonjwa sugu. \xA9 2026 Bioforce Europa. Haki zote zimehifadhiwa." }) })
    ] }),
    /* @__PURE__ */ jsx(StickyForm, {})
  ] });
}
export {
  LandingPage
};
