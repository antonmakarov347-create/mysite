import { jsx, jsxs } from "react/jsx-runtime";
import { OrderForm } from "./order-form";
function StickyForm() {
  return /* @__PURE__ */ jsx("div", { className: "pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "sticky-order pointer-events-auto w-full max-w-md border-t border-gold/40 bg-navy-deep/95 shadow-2xl backdrop-blur-md", children: /* @__PURE__ */ jsxs("div", { className: "px-3 pt-2.5", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-1.5 flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-2", children: [
        /* @__PURE__ */ jsx("span", { className: "font-display text-lg font-extrabold tabular-nums text-gold-bright", children: "6,750 KES" }),
        /* @__PURE__ */ jsx("span", { className: "text-sm font-semibold text-cream/50 line-through", children: "13,500" })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "rounded-sm bg-cta px-2 py-0.5 text-xs font-extrabold uppercase tracking-wide text-paper", children: "Punguzo 50%" })
    ] }),
    /* @__PURE__ */ jsx(OrderForm, { idPrefix: "sticky", compact: true })
  ] }) }) });
}
export {
  StickyForm
};
