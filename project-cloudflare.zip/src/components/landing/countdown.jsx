import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
function remainingSeconds() {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Nairobi",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hourCycle: "h23"
    }).formatToParts(/* @__PURE__ */ new Date()).map((part) => [part.type, part.value])
  );
  const used = Number(parts.hour ?? 0) * 3600 + Number(parts.minute ?? 0) * 60 + Number(parts.second ?? 0);
  return Math.max(0, 24 * 3600 - used);
}
function pad(value) {
  return String(value).padStart(2, "0");
}
function Countdown() {
  const [seconds, setSeconds] = useState(null);
  useEffect(() => {
    setSeconds(remainingSeconds());
    const id = window.setInterval(() => setSeconds(remainingSeconds()), 1e3);
    return () => window.clearInterval(id);
  }, []);
  const h = seconds === null ? "00" : pad(Math.floor(seconds / 3600));
  const m = seconds === null ? "00" : pad(Math.floor(seconds % 3600 / 60));
  const s = seconds === null ? "00" : pad(seconds % 60);
  return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center gap-2", suppressHydrationWarning: true, children: [
    { label: "Saa", value: h },
    { label: "Dakika", value: m },
    { label: "Sekunde", value: s }
  ].map((item) => /* @__PURE__ */ jsxs("div", { className: "min-w-16 rounded-md bg-navy-deep px-2 py-1.5 text-center", children: [
    /* @__PURE__ */ jsx("div", { className: "font-display text-xl font-extrabold tabular-nums text-gold-bright", children: item.value }),
    /* @__PURE__ */ jsx("div", { className: "text-xs font-bold uppercase tracking-wider text-cream/60", children: item.label })
  ] }, item.label)) });
}
export {
  Countdown
};
