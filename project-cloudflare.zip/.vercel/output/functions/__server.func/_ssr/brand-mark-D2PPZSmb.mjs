import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/brand-mark-D2PPZSmb.js
var import_jsx_runtime = require_jsx_runtime();
function BrandMark({ compact = false, tone = "dark" }) {
	const word = tone === "dark" ? "text-gold-bright" : "text-navy";
	const sub = tone === "dark" ? "text-gold/80" : "text-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 64 64",
			className: compact ? "size-8" : "size-11",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 4.5 54 15.2v18.6c0 14.6-9.3 25.8-22 29.7C19.3 59.6 10 48.4 10 33.8V15.2Z",
				className: "fill-navy-deep stroke-gold",
				strokeWidth: "3"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M36.2 14 22 34.4h11.2L24.8 50.5 43.6 31H32.2L36.2 14Z",
				className: "fill-gold-bright"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `font-display font-extrabold tracking-wide ${word} ${compact ? "text-sm" : "text-lg"}`,
				children: "BIOFORCE"
			}), !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-xs font-semibold uppercase tracking-widest ${sub}`,
				children: "Europa · Kenya"
			}) : null]
		})]
	});
}
//#endregion
export { BrandMark as t };
