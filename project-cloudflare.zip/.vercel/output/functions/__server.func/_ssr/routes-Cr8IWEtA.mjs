import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Star, c as PhoneCall, d as Clock, g as BadgeCheck, h as Check, i as TriangleAlert, l as Package, m as ChevronDown, o as Sparkles, p as ChevronRight, r as Truck, s as Shield, t as Zap, u as Leaf } from "../_libs/lucide-react.mjs";
import { t as BrandMark } from "./brand-mark-D2PPZSmb.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cr8IWEtA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DRCASH_SRC = "https://static.statthroat.tech/dist/api/lead-1.1.0.min.js";
var TOKEN = "ZGFLYWUXOGUTYJE1ZC00MDLLLWEZMJKTZMYYNDC5YJQ2NTLK";
var STREAM_CODE = "ndb1q";
function initDrCash() {
	if (typeof window === "undefined") return () => {};
	const start = () => {
		const drlead = window.drlead;
		if (!drlead || window.__drleadInited) return;
		window.__drleadInited = true;
		drlead.init({
			params: {
				token: TOKEN,
				stream_code: STREAM_CODE,
				thanks_page: "/thanks"
			},
			subs: {
				sub1: drlead.formInputGet("sub1") || drlead.queryGet("sub1"),
				sub2: drlead.formInputGet("sub2") || drlead.queryGet("sub2"),
				sub3: drlead.formInputGet("sub3") || drlead.queryGet("sub3"),
				sub4: drlead.formInputGet("sub4") || drlead.queryGet("sub4"),
				sub5: drlead.formInputGet("sub5") || drlead.queryGet("sub5")
			},
			callback: function() {},
			before: function() {}
		});
	};
	if (window.drlead) {
		start();
		return () => {};
	}
	const existing = document.querySelector("script[data-drcash]");
	if (existing) {
		existing.addEventListener("load", start);
		return () => existing.removeEventListener("load", start);
	}
	const script = document.createElement("script");
	script.src = DRCASH_SRC;
	script.async = true;
	script.dataset.drcash = "1";
	script.addEventListener("load", start);
	document.body.appendChild(script);
	return () => script.removeEventListener("load", start);
}
function remainingSeconds() {
	const parts = Object.fromEntries(new Intl.DateTimeFormat("en-GB", {
		timeZone: "Africa/Nairobi",
		hour: "numeric",
		minute: "numeric",
		second: "numeric",
		hourCycle: "h23"
	}).formatToParts(/* @__PURE__ */ new Date()).map((part) => [part.type, part.value]));
	const used = Number(parts.hour ?? 0) * 3600 + Number(parts.minute ?? 0) * 60 + Number(parts.second ?? 0);
	return Math.max(0, 86400 - used);
}
function pad(value) {
	return String(value).padStart(2, "0");
}
function Countdown() {
	const [seconds, setSeconds] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setSeconds(remainingSeconds());
		const id = window.setInterval(() => setSeconds(remainingSeconds()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	const h = seconds === null ? "00" : pad(Math.floor(seconds / 3600));
	const m = seconds === null ? "00" : pad(Math.floor(seconds % 3600 / 60));
	const s = seconds === null ? "00" : pad(seconds % 60);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-2",
		suppressHydrationWarning: true,
		children: [
			{
				label: "Saa",
				value: h
			},
			{
				label: "Dakika",
				value: m
			},
			{
				label: "Sekunde",
				value: s
			}
		].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-16 rounded-md bg-navy-deep px-2 py-1.5 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-xl font-extrabold tabular-nums text-gold-bright",
				children: item.value
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-bold uppercase tracking-wider text-cream/60",
				children: item.label
			})]
		}, item.label))
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function sanitizePhone(value) {
	return value.replace(/\s/g, "");
}
function OrderForm({ idPrefix, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "orderForm flex flex-col gap-2",
		method: "post",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("grid gap-2", compact ? "grid-cols-2" : "grid-cols-1"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Jina"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold uppercase tracking-wide text-cream/80",
					children: "Jina"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: `${idPrefix}-name`,
					name: "name",
					type: "text",
					required: true,
					autoComplete: "name",
					placeholder: "Jina lako",
					suppressHydrationWarning: true,
					className: "h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted focus:border-gold"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Nambari ya simu"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold uppercase tracking-wide text-cream/80",
					children: "Nambari ya simu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: `${idPrefix}-phone`,
					name: "phone",
					type: "tel",
					inputMode: "tel",
					required: true,
					minLength: 5,
					autoComplete: "tel",
					placeholder: "07XXXXXXXX",
					suppressHydrationWarning: true,
					className: "only_number h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted focus:border-gold",
					onInput: (event) => {
						const target = event.currentTarget;
						target.value = sanitizePhone(target.value);
					}
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "submit",
			className: "cta-pulse button__text h-12 w-full rounded-md bg-cta text-base font-extrabold uppercase tracking-wide text-paper shadow-lg hover:bg-cta-dark",
			children: "Agiza sasa — 6,750 KES"
		})]
	});
}
var QUESTIONS = [
	{
		title: "1. Baada ya siku ndefu ya kazi, viungo vyako huhisi vizito na ngumu:",
		options: [
			"Mara chache",
			"Mara nyingi sana",
			"Kila wakati"
		]
	},
	{
		title: "2. Umewahi kupata majeraha, kuteguka, michubuko au kuvunjika?",
		options: [
			"Ndiyo, kila baada ya miaka michache",
			"Hakuna kilichohitaji hospitali",
			"Majeraha madogo tu"
		]
	},
	{
		title: "3. Una miaka mingapi?",
		options: [
			"Chini ya 30",
			"30 – 45",
			"Zaidi ya 45"
		]
	}
];
function Quiz() {
	const [step, setStep] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const done = step >= QUESTIONS.length;
	const question = QUESTIONS[step];
	function goNext() {
		if (picked === null) return;
		setPicked(null);
		setStep((value) => value + 1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-navy p-5 text-paper shadow-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-xs font-bold uppercase tracking-widest text-gold",
					children: "Uchunguzi wa haraka"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: "Je, unahitaji Bioforce? Jibu maswali 3"
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 rounded-lg bg-navy-deep p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm leading-relaxed text-cream",
						children: [
							"Jeraha au mchubuko linaweza kutokea wakati wowote.",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-gold-bright",
								children: "Bioforce"
							}),
							" husaidia kupunguza maumivu, kuvimba na ugumu — na kuchochea cartilage yenye afya. Kozi ya kapsuli 30 inakupa faraja ya kila siku."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#oda",
						className: "mt-4 flex h-12 items-center justify-center rounded-md bg-cta text-sm font-extrabold uppercase tracking-wide text-paper",
						children: "Pata ofa ya 50%"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm font-semibold leading-snug",
							children: question.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: question.options.map((option, index) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPicked(index),
									className: `flex min-h-11 w-full items-center rounded-md border px-3 py-2 text-left text-sm font-medium ${picked === index ? "border-gold bg-gold/15 text-gold-bright" : "border-paper/15 bg-navy-deep text-cream"}`,
									children: option
								}) }, option);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: picked === null,
							onClick: goNext,
							className: "mt-4 flex h-12 w-full items-center justify-center gap-1 rounded-md bg-gold text-sm font-extrabold uppercase tracking-wide text-navy-deep disabled:opacity-40",
							children: ["Endelea", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-center text-xs text-cream/50",
							children: [
								"Swali ",
								step + 1,
								" kati ya ",
								QUESTIONS.length
							]
						})
					]
				})
			]
		})
	});
}
function StickyForm() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "sticky-order pointer-events-auto w-full max-w-md border-t border-gold/40 bg-navy-deep/95 shadow-2xl backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3 pt-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1.5 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-extrabold tabular-nums text-gold-bright",
							children: "6,750 KES"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-cream/50 line-through",
							children: "13,500"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-cta px-2 py-0.5 text-xs font-extrabold uppercase tracking-wide text-paper",
						children: "Punguzo 50%"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderForm, {
					idPrefix: "sticky",
					compact: true
				})]
			})
		})
	});
}
var BENEFITS = [
	"Inapunguza maumivu ya viungo na mgongo",
	"Inachochea kuzaliwa upya kwa cartilage",
	"Inapunguza ugumu, mvutano wa misuli na uvimbe",
	"Inasaidia unyumbufu, mwendo na faraja",
	"Inazuia kuvimba na kulinda kiungo"
];
var ADVANTAGES = [
	{
		icon: Sparkles,
		title: "Madhara mengi kwa pamoja",
		text: "Husaidia viungo, mgongo, ugumu wa asubuhi na majeraha ya zamani."
	},
	{
		icon: Shield,
		title: "Salama — bila madhara makali",
		text: "Muundo wa asili, unaofaa kwa matumizi ya kila siku au kozi kamili."
	},
	{
		icon: Leaf,
		title: "Vipengele vya mimea 100%",
		text: "Mimea hai pekee — hakuna steroidi wala dawa za kulevya."
	},
	{
		icon: Zap,
		title: "Ufanisi unaoonekana",
		text: "Wengi huripoti faraja baada ya siku chache za matumizi ya kawaida."
	},
	{
		icon: BadgeCheck,
		title: "Imepimwa na wataalamu",
		text: "Imetajwa Poland. Inakidhi viwango vya ubora vya Europa."
	}
];
var STEPS_USE = [
	"Kumeza kapsuli 1 na glasi ya maji, baada ya chakula.",
	"Tumia mara 1–2 kwa siku — asubuhi na jioni.",
	"Endelea kwa siku 30 (chupa 1) kwa matokeo thabiti."
];
var STEPS_ORDER = [
	{
		icon: Package,
		text: "Jaza jina na nambari ya simu kwenye fomu"
	},
	{
		icon: PhoneCall,
		text: "Opereta atakupigia kuthibitisha oda"
	},
	{
		icon: Truck,
		text: "Lipa bidhaa unapoipokea — Kenya nzima"
	}
];
var REVIEWS = [
	{
		name: "Amina W.",
		place: "Nairobi, miaka 52",
		text: "Goti langu lilikuwa linaniuma kila nitembee soko. Baada ya wiki mbili za Bioforce, ninatembea bila kuogopa ngazi."
	},
	{
		name: "John K.",
		place: "Kisumu, miaka 61",
		text: "Mgongo ulikuwa unanishika kila asubuhi. Sasa naamka, naweza kufanya kazi shambani bila kulazimisha."
	},
	{
		name: "Grace M.",
		place: "Mombasa, miaka 47",
		text: "Vidole vilikuwa vimekaza, sikuweza kushona. Faraja imerudi — nimeagiza chupa ya pili."
	},
	{
		name: "Peter O.",
		place: "Nakuru, miaka 58",
		text: "Nilikuwa na wasiwasi ni bandia. Opereta alieleza vizuri, chupa ilifika kwa siku 2. Ninaendelea na kozi."
	}
];
var FAQ = [
	{
		q: "Bioforce ni nini?",
		a: "Ni kapsuli 30 za lishe ya viungo — Bioforce Europa. Inasaidia unyumbufu, faraja, cartilage yenye afya na kupunguza ugumu na kuvimba."
	},
	{
		q: "Inachukua muda gani kuona tofauti?",
		a: "Wengi huhisi faraja ndani ya siku 5–10. Kozi kamili ya siku 30 inapendekezwa ili cartilage na viungo vipate msaada thabiti."
	},
	{
		q: "Kuna madhara?",
		a: "Muundo ni wa mimea. Ikiwa una mzio, una mimba, au unatumia dawa nyingine, shauri na daktari kabla ya kuanza."
	},
	{
		q: "Nitalipaje?",
		a: "Unalipa unapopokea bidhaa (cash on delivery). Hakuna malipo ya awali kwenye simu."
	},
	{
		q: "Inafika wapi Kenya?",
		a: "Tunatuma Nairobi, Mombasa, Kisumu, Nakuru, Eldoret na kaunti nyingine. Opereta atakwambia gharama ya usafirishaji kabla hujaidhinisha."
	},
	{
		q: "Ni kapsuli ngapi kwenye chupa?",
		a: "Kapsuli 30 — kozi ya takriban mwezi mmoja ikiwa unatumia moja kwa siku."
	},
	{
		q: "Watoto wanaweza kutumia?",
		a: "Bidhaa hii ni kwa watu wazima. Usitoe kwa watoto bila ushauri wa daktari."
	}
];
function SectionTitle({ kicker, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-4",
		children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 text-xs font-bold uppercase tracking-widest text-gold",
			children: kicker
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-bold leading-snug text-ink",
			children
		})]
	});
}
function FaqList() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-paper",
		children: FAQ.map((item, index) => {
			const isOpen = open === index;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex min-h-12 w-full items-center justify-between gap-3 px-4 py-3 text-left",
				onClick: () => setOpen(isOpen ? -1 : index),
				"aria-expanded": isOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-bold text-ink",
					children: item.q
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-4 shrink-0 text-navy transition-transform ${isOpen ? "rotate-180" : ""}` })]
			}), isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pb-4 text-sm leading-relaxed text-muted",
				children: item.a
			}) : null] }, item.q);
		})
	});
}
function LandingPage() {
	(0, import_react.useEffect)(() => initDrCash(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-navy-deep",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto min-h-screen w-full max-w-md bg-cream pb-52 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 bg-navy-deep" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 bg-gold" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 bg-green" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between bg-navy px-4 py-2 text-xs font-semibold text-cream",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-3.5 text-gold" }), "Kenya nzima"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lipa unapopokea" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold-bright",
							children: "Ofa 50%"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "relative overflow-hidden bg-navy px-4 pb-28 pt-6 text-paper",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs font-bold uppercase tracking-widest text-gold",
							children: "Kapsuli za viungo · 30 kapsuli"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-3xl font-extrabold leading-tight",
							children: "Viungo vinauma au mgongo unashindwa?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm leading-relaxed text-cream/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-gold-bright",
								children: "Bioforce Europa"
							}), " ni kapsuli za asili zinazosaidia unyumbufu, faraja, cartilage yenye afya — na kupunguza ugumu na kuvimba."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							className: "absolute inset-x-0 bottom-0 h-12 w-full text-cream",
							viewBox: "0 0 400 48",
							preserveAspectRatio: "none",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M0 48 C80 8 140 8 200 24 C280 44 320 0 400 24 L400 48 Z",
								fill: "currentColor"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative z-10 -mt-24 px-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-xl bg-paper shadow-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative bg-paper",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/product.jpg",
								alt: "Chupa ya kapsuli za Bioforce Europa, kapsuli 30",
								className: "mx-auto h-72 w-full object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute left-3 top-3 rounded-full bg-cta px-3 py-2 text-center shadow-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold uppercase text-paper",
									children: "Punguzo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl font-extrabold leading-none text-paper",
									children: "50%"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 px-4 py-4",
							children: BENEFITS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2 text-sm font-medium text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "mt-0.5 size-4 shrink-0 text-green",
									strokeWidth: 3
								}), item]
							}, item))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "px-4 pt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-green px-4 py-5 text-center text-paper shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-widest text-gold-bright",
								children: "Bei ya ofa leo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex items-end justify-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-4xl font-extrabold tabular-nums",
									children: "6,750"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pb-1 text-lg font-bold",
									children: "KES"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: [
									"Bei ya kawaida",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold line-through opacity-80",
										children: "13,500 KES"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "stock-blink mt-3 text-xs font-bold uppercase tracking-wide text-gold-bright",
								children: "Chupa 19 zimesalia kwa bei hii"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#oda",
								className: "cta-pulse mt-4 flex h-12 items-center justify-center rounded-md bg-cta text-sm font-extrabold uppercase tracking-wide text-paper",
								children: "Agiza sasa"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Tatizo",
							children: "Maumivu ya viungo yanaiba siku zako"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "Kazi ya shamba, kusimama sokoni, kukaa ofisini, au umri — viungo huchakaa. Ugumu wa asubuhi, goti linalolia ngazi, mgongo unaoshindwa kuinama. Wakenya wengi huvumilia hadi faraja ya kawaida inapotea."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/kenya.jpg",
							alt: "Milima ya Kenya yenye kijani — tunatuma nchi nzima",
							className: "mt-4 h-40 w-full rounded-xl object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "Bioforce imeundwa kusaidia cartilage, kupunguza kuvimba na kurudisha mwendo. Si dawa ya muujiza wa usiku mmoja — ni msaada wa kila siku, chupa moja ya kapsuli 30."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Jinsi inavyofanya kazi",
							children: "Cartilage yenye afya, viungo vyenye faraja"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/joint.jpg",
							alt: "Mchoro wa kiungo na cartilage",
							className: "mb-4 h-56 w-full rounded-xl object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 text-sm leading-relaxed text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-ink",
								children: "Bioforce"
							}), " inalenga osteochondrosis, osteoarthritis na majeraha ya zamani. Inapunguza mshtuko wa misuli na kuvimba, inapunguza kasi ya uharibifu wa cartilage, na inaboresha mzunguko ili kiungo kipate lishe."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Matumizi ya kawaida husaidia kusimamisha maumivu ya viungo na mgongo. Wengi huhisi tofauti baada ya siku chache — kozi kamili inalinda matokeo." })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#oda",
							className: "mt-4 flex h-12 items-center justify-center rounded-md bg-navy text-sm font-extrabold uppercase tracking-wide text-gold-bright",
							children: "Bioforce hutumia vipengele hai"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Muundo",
							children: "Mimea hai, si kemikali kali"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/herbs.jpg",
							alt: "Mimea ya asili inayotumika katika nyongeza ya viungo",
							className: "mb-4 h-44 w-full rounded-xl object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-2 gap-2",
							children: [
								"Msaada wa cartilage",
								"Kupunguza kuvimba",
								"Unyumbufu wa kiungo",
								"Faraja ya kila siku"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-lg bg-paper px-3 py-3 text-center text-xs font-bold text-navy shadow-sm",
								children: item
							}, item))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiz, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						kicker: "Kwa nini Bioforce",
						children: "Faida za kapsuli kwa mgongo na viungo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: ADVANTAGES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 shrink-0 items-center justify-center rounded-lg bg-navy text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-sm font-bold uppercase tracking-wide text-navy",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: item.text
							})] })]
						}, item.title))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Matumizi",
							children: "Jinsi ya kutumia Bioforce"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/capsules.jpg",
							alt: "Kapsuli nyeupe za Bioforce",
							className: "mb-4 h-40 w-full rounded-xl object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "space-y-3",
							children: STEPS_USE.map((text, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 rounded-xl bg-paper p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-green font-display text-sm font-extrabold text-paper",
									children: index + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium leading-relaxed text-ink",
									children: text
								})]
							}, text))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						kicker: "Ushuhuda",
						children: "Wakenya wanaosema wamerudi kutembea"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: REVIEWS.map((review) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-paper p-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 items-center justify-center rounded-full bg-navy font-display text-sm font-bold text-gold",
										children: review.name.slice(0, 1)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-ink",
										children: review.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: review.place
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto flex gap-0.5 text-gold",
										children: Array.from({ length: 5 }).map((_, star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-gold text-gold" }, star))
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: [
									"“",
									review.text,
									"”"
								]
							})]
						}, review.name))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "px-4 pt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border-2 border-cta bg-paper p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center gap-2 text-cta-dark",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-base font-extrabold uppercase",
								children: "Jihadhari na bandia"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "Agiza tu kupitia fomu hii rasmi. Opereta atathibitisha oda na anwani. Usilipie kwa M-Pesa kabla ya kupokea bidhaa — Bioforce hulipwa unapopokea."
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						kicker: "Oda",
						children: "Jinsi ya kuagiza Bioforce Kenya"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: STEPS_ORDER.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-12 shrink-0 items-center justify-center rounded-full bg-navy text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-semibold text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mr-2 font-display text-gold",
									children: [index + 1, "."]
								}), item.text]
							})]
						}, item.text))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 pt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						kicker: "Maswali",
						children: "Maswali yanayoulizwa sana"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "oda",
					className: "scroll-mt-4 px-4 py-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-navy p-5 text-paper shadow-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-center text-xs font-bold uppercase tracking-widest text-gold",
								children: "Ofa ndogo yenye punguzo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-center font-display text-2xl font-bold",
								children: "Bioforce Europa — 30 kapsuli"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex items-end justify-center gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-4xl font-extrabold tabular-nums text-gold-bright",
									children: "6,750 KES"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-center text-sm text-cream/70 line-through",
								children: "13,500 KES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto mt-3 w-fit rounded-full bg-green px-3 py-1 text-xs font-bold uppercase tracking-wide",
								children: "Lipa unapopokea · Kenya nzima"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderForm, { idPrefix: "main" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-cream/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }), "Opereta atakupigia leo, simu iwe wazi"]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "px-4 pb-8 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted",
						children: "Bioforce ni nyongeza ya lishe, si dawa, na haichukui nafasi ya ushauri wa daktari. Shauri na mtaalamu kabla ya matumizi, hasa ukiwa na magonjwa sugu. © 2026 Bioforce Europa. Haki zote zimehifadhiwa."
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyForm, {})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingPage, {});
}
//#endregion
export { Home as component };
