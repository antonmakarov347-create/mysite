import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PhoneCall, f as CircleCheck, n as Volume2 } from "../_libs/lucide-react.mjs";
import { t as BrandMark } from "./brand-mark-D2PPZSmb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thanks-DciMchSU.js
var import_jsx_runtime = require_jsx_runtime();
function ThanksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-navy-deep",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen w-full max-w-md flex-col bg-cream px-5 pb-10 pt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { tone: "light" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-1 flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-20 items-center justify-center rounded-full bg-green text-paper shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
							className: "size-12",
							strokeWidth: 2.2
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 font-display text-3xl font-extrabold leading-tight text-ink",
						children: "Asante kwa ununuzi wako!"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-base leading-relaxed text-ink",
						children: "Hakikisha simu yako imewashwa — opereta wetu atakupigia hivi karibuni."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-8 w-full space-y-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "mt-0.5 size-5 shrink-0 text-navy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: "Tafadhali usikatae simu isiyojulikana. Inaweza kuwa opereta anayethibitisha oda yako."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 rounded-xl bg-paper p-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "mt-0.5 size-5 shrink-0 text-navy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: "Weka sauti wazi na uhakikishe simu haiko kwenye mode ya kimya."
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 w-full overflow-hidden rounded-xl bg-navy p-4 text-left text-paper",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-widest text-gold",
								children: "Oda yako"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-lg font-bold",
								children: "Bioforce Europa · 30 kapsuli"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-gold-bright",
								children: "6,750 KES · Lipa unapopokea"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/product.jpg",
						alt: "Chupa ya Bioforce Europa",
						className: "mt-6 h-48 w-full object-contain"
					})
				]
			})]
		})
	});
}
//#endregion
export { ThanksPage as component };
