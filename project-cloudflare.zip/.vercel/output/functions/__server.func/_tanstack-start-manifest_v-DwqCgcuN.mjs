//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DwqCgcuN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/thanks"],
		preloads: ["/assets/index-CVX6GVVT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVX6GVVT.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DKiPUFbw.js", "/assets/brand-mark-3IAbiFJf.js"]
	},
	"/thanks": {
		filePath: "/workspace/src/routes/thanks.tsx",
		children: void 0,
		preloads: ["/assets/thanks-DVFts9Kj.js", "/assets/brand-mark-3IAbiFJf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
